# bluepill_ws2812
Blue Pill STM32F103C8 Neopixel WS2812 driver

I got tired of the broken FastLED support for WS2812 LEDs on the Blue Pill processor module.  This is a crude WS2812 LED driver specifically for the Blue Pill (STM32F103C8).  Any digital pins can be used, multiple pins can be used with multiple strings.
